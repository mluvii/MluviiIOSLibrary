//
//  MluviiLibrary.h
//  MluviiLibrary
//
//  Created by Mluvi Mac on 12/02/2019.
//  Copyright © 2019 Mluvii. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MluviiLibrary.
FOUNDATION_EXPORT double MluviiLibraryVersionNumber;

//! Project version string for MluviiLibrary.
FOUNDATION_EXPORT const unsigned char MluviiLibraryVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MluviiLibrary/PublicHeader.h>


